# School project ;)

A Pen created on CodePen.io. Original URL: [https://codepen.io/Fresh7/pen/BaYdVYo](https://codepen.io/Fresh7/pen/BaYdVYo).

Inspired by: https://dribbble.com/shots/15346148-Product-List